# Country API 🔥
![index](https://github.com/Daniels-not/countries-api/blob/master/preview.PNG)

## Functionalities ✨

- Get Country ✔️

- Search Country (COMING SOON) ✔️

## Technologies used in this project ❤️

![VUEJS](https://img.shields.io/badge/Vue.js-35495E?style=for-the-badge&logo=vue.js&logoColor=4FC08D) ![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
