const button = document.querySelector("button");

button.onclick = function () {
  alert("ouch!");
};
